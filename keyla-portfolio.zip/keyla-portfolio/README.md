# Keyla's Portfolio

Personal portfolio of Keyla Alemán, Growth Marketer for B2B SaaS.

- `index.html` is the whole site.
- `img/` holds every image the site uses.

Published with GitHub Pages.
